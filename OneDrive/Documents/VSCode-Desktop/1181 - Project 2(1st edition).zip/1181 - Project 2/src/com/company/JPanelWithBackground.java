package com.company;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class JPanelWithBackground extends JPanel {

    private Image backgroundImage;

    public JPanelWithBackground(String fileName) throws IOException {
        backgroundImage = ImageIO.read(new File(fileName));
    }

    JFrame f = new JFrame("stackoverflow") {
        private Image backgroundImage = ImageIO.read(new File("C:/Users/regin/IdeaProjects/1181 - Project 2/resources/scp.jpg"));
        public void paint( Graphics g ) {
            super.paint(g);
            g.drawImage(backgroundImage, 0, 0, null);
        }
    };

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawImage(backgroundImage, 0, 0, this);
    }
}