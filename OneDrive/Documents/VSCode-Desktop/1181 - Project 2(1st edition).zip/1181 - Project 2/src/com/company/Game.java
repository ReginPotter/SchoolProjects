package com.company;

import java.util.ArrayList;
import java.util.Random;

public class Game {

    boolean gen1Start = false;
    boolean gen2Start = false;
    boolean gen3Start = false;
    boolean gen4Start = false;
    int generators = 1;

    public Game() {

    }

    public Room createRoom() {
        Random rng = new Random();
        Room room = new Room();
        int name = 0;
        int exits = 0;

        room.setIsGen();

        if(room.getIsGen()) {
            room.setName("Generator Room #" + generators);
            generators++;
            return room;
        } else {

            do {
                exits = rng.nextInt(5);
            } while (exits == 0);
            room.setExits(exits);

            do {
                name = rng.nextInt(999);
            } while (name < 99);

            if (room.getExits() == 4) {
                room.setName("Four-Way Hallway #" + name);
            } else if (room.getExits() == 3) {
                room.setName("T Shaped Hallway #" + name);
            } else if (room.getExits() == 2) {
                room.setName("Straight Hallway #" + name);
            } else {
                room.setName("Dead End #" + name);
            }

            room.setIsEnemyHere();
        }

        return room;
    }

    public boolean roomWorks(Room room) {
        if(room.getName().equalsIgnoreCase("Generator Room #1")) {
            if(gen1Start) {
                return false;
            } else {
                gen1Start = true;
                return true;

            }
        } else if(room.getName().equalsIgnoreCase("Generator Room #2")) {
            if(gen2Start) {
                return false;
            } else {
                gen2Start = true;
                return true;
            }
        } else if(room.getName().equalsIgnoreCase("Generator Room #3")) {
            if(gen3Start) {
                return false;
            } else {
                gen3Start = true;
                return true;
            }
        } else if(room.getName().equalsIgnoreCase("Generator Room #4")) {
            if(gen4Start) {
                return false;
            } else {
                gen4Start = true;
                return true;
            }
        }
        return true;
    }

    public boolean gameOver(Room room) {
        if(room.getName().equalsIgnoreCase("Elevator #4")) {
            if (gen1Start && gen2Start && gen3Start && gen4Start) {
                return true;
            }
        }
        return false;
    }
}
