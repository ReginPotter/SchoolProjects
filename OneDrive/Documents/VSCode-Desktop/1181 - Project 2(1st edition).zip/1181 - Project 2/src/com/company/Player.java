package com.company;

public class Player {
    private Room roomIn;
    private boolean isSafe;

    public Player(Room roomIn, boolean isSafe) {
        this.roomIn = roomIn;
        this.isSafe = roomIn.getIsSafe();
    }

    public Room getRoomIn() {
        return roomIn;
    }

    public boolean getIsSafe() {
        return isSafe;
    }

    public void setRoomIn(Room roomIn) {
        this.roomIn = roomIn;
    }

    public String toString() {
        String s = "You are in room ";

        s += roomIn.getName() + " and it is ";

        if(isSafe) {
            s += "safe.";
        } else {
            s += "not safe.";
        }

        return s;
    }
}
