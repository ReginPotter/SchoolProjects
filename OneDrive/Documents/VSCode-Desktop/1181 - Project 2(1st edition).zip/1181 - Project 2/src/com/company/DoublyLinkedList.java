package com.company;

public class DoublyLinkedList {

    private Node<Room> head;
    private Node<Room> tail;


    public void add(Room newRoom) {
        Node<Room> newerRoom = new Node<>(newRoom);
        if (head == null) {
            head = newerRoom;
            tail = newerRoom;
        } else if (this.size() == 1) {
            tail.previous = head;
            tail.next = newerRoom;
            tail = newerRoom;
        } else {
            tail.previous = tail;
            tail.next = newerRoom;
            tail = newerRoom;
        }
    }

    public int size() {
        int size = 0;

        Node<Room> current = head;
        while (current != null) {
            current = current.next;
            size++;
        }
        return size;
    }

    public void print() {
        Node<Room> current = head;
        while (current != null) {
            System.out.print(current.element + " ");
            current = current.next;
        }
        System.out.println();
    }

    public Room getItemAt(int index) {
        Node<Room> current = head;
        for (int i=0; i<index; i++) {
            current = current.next;
            if (current == null) {
                break;
            }
        }
        if (current != null) {
            return current.element;
        } else {
            System.out.println("Invalid index!");
        }
        return null;
    }

    public Room goBack(int index, int numBack) {
        //System.out.println(index);
        //System.out.println(numBack);
        Node<Room> current = head;
        for (int i=0; i<index - numBack; i++) {
            current = current.next;
            if (current == null) {
                break;
            }
        }
        if (current != null) {
            return current.element;
        } else {
            System.out.println("Invalid index!");
        }
        return null;
    }

    public void deleteLast() {
        Node<Room> current = head;

        for(int i=0; i<this.size() - 2; i++) {
            current = current.next;

            if(current == null) {
                break;
            }
        }
        Node<Room> temp = tail;

        tail = current;
        tail.next = null;
        tail.previous = current.previous;
    }
}
