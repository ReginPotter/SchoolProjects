package com.company;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Block extends JPanel {

    private int rotation;
    private Object Images;
    private Image myImage;

    public Block(){
    }

    //@Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.drawImage(myImage, 0, 0, null);
    }

    public void changeImage(Image img) {
        this.myImage = img;
        repaint();
    }

}