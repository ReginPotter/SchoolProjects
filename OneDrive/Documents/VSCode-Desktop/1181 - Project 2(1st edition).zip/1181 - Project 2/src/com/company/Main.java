package com.company;

import javax.imageio.ImageIO;
import javax.print.Doc;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.Document;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.concurrent.Flow;

class Main extends JFrame {

    JLabel background;
    JButton left;
    JButton right;
    JButton forward;
    JButton back;
    JSlider slider;
    int numBack;
    boolean gen1Start = false;
    boolean gen2Start = false;
    boolean gen3Start = false;
    boolean gen4Start = false;
    JProgressBar blink;
    private int time = 100;
    Timer timer = null;
    JLabel timeLabel;

    public Main() throws IOException {

        // this creates the root JPanel
        JPanel root = new JPanel() {

            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image image = null;
                try {
                    image = ImageIO.read(new File("resources/scp.jpg"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                g.drawImage(image, -240, -230, null);
            }
        };
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel startMenu = new JPanel();
        startMenu.setLayout(new GridLayout());
        startMenu.setOpaque(false);

        blink = new JProgressBar(SwingConstants.VERTICAL);
        blink.setValue(0);
        blink.setStringPainted(true);
        blink.setMaximum(100);
        blink.setMinimum(0);
        blink.setString("blink");

        JLabel gameName = new JLabel();
        gameName.setForeground(Color.white);
        gameName.setOpaque(false);
        gameName.setFont(new Font("Arial", Font.PLAIN, 30));
        gameName.setText("SCP - Containment Breach");
        gameName.setBackground(Color.black);
        gameName.setHorizontalAlignment(JLabel.CENTER);

        JPanel startButtons = new JPanel();
        startButtons.setBackground(Color.black);
        startButtons.setOpaque(false);
        startButtons.setBorder(new EmptyBorder(10, 10 ,10, 10));
        startButtons.setLayout(new FlowLayout());

        JButton start = new JButton("Start");
        start.setBackground(Color.black);
        start.setForeground(Color.white);

        start.addActionListener(e -> {

            Game newGame = new Game();
            DoublyLinkedList rooms = new DoublyLinkedList();
            Room startRoom = new Room("Elevator #4", 4, false, true, false);
            rooms.add(startRoom);

//            timeLabel = new JLabel("Time: " + time);

            JPanel game = new JPanel();
            game.setLayout(new BorderLayout());
            game.setOpaque(true);

            JPanel helpInfo = new JPanel();
            helpInfo.setLayout(new BoxLayout(helpInfo, BoxLayout.Y_AXIS));

            ImageIcon img = new ImageIcon("resources/help.jpg");
            JButton help = new JButton("");
            help.setIcon(img);
            help.setAlignmentX(LEFT_ALIGNMENT);
            help.setBackground(Color.black);
            help.setForeground(Color.white);

            background = new JLabel();
            background.setIcon(new ImageIcon("resources/4_entrances.jpg"));

            JPanel west = new JPanel();
            west.setLayout(new BorderLayout());

            JPanel arrowButtons = new JPanel();
            arrowButtons.setLayout(new GridLayout(2, 2));

            right = new JButton("->");

            left = new JButton("<-");

            forward = new JButton("^");

            back = new JButton("v");

            JButton startGen = new JButton("Start Gen");
            startGen.setVisible(false);

            slider = new JSlider(JSlider.VERTICAL, 0, 5, 0);
            slider.setMajorTickSpacing(1);
            slider.setSnapToTicks(true);
            slider.setPaintTicks(true);
            slider.setVisible(false);

            arrowButtons.add(left);
            arrowButtons.add(right);
            arrowButtons.add(forward);
            arrowButtons.add(back);

            west.add(arrowButtons, BorderLayout.SOUTH);
            west.add(blink, BorderLayout.CENTER);
            west.add(startGen, BorderLayout.NORTH);

            helpInfo.add(help);
            helpInfo.add(slider);

            game.add(west, BorderLayout.WEST);
            game.add(helpInfo, BorderLayout.EAST);
            game.add(background, BorderLayout.CENTER);

            this.getContentPane().add(game);

            root.setVisible(false);
            game.setVisible(true);

            help.addActionListener(f -> {
                game.setVisible(false);
                root.setVisible(true);

                this.setExtendedState(JFrame.MAXIMIZED_BOTH);
            });

            left.addActionListener(f -> {
                slider.setValue(0);
                startGen.setVisible(false);
                forward.setEnabled(true);
                left.setEnabled(true);
                right.setEnabled(true);

                numBack = 0;

                Room room = newGame.createRoom();
                room.setIsGen();
                rooms.add(room);

                if(room.getIsGen()) {
                    if (!newGame.roomWorks(room)) {
                        startGen.setEnabled(false);
                    }
                    startGen.setVisible(true);
                    left.setEnabled(false);
                    right.setEnabled(false);
                    background.setIcon(new ImageIcon("resources/generator_room.jpg"));
                    startGen.addActionListener(h -> {
                        JButton run = new JButton("run");
                        run.setVisible(true);
                        startGen.setVisible(false);

                        west.add(run, BorderLayout.NORTH);


                        background.setIcon(new ImageIcon("resources/generator.jpg"));
                        slider.setVisible(true);

                        right.setEnabled(false);
                        left.setEnabled(false);
                        forward.setEnabled(false);
                        back.setEnabled(false);

                        run.addActionListener(g -> {
                            if (slider.getValue() == 5) {
                                background.setIcon(new ImageIcon("resources/generator_room.jpg"));
                                right.setEnabled(false);
                                left.setEnabled(false);
                                forward.setEnabled(true);
                                back.setEnabled(true);
                                slider.setVisible(false);
                                run.setVisible(false);
                                if(!gen1Start) {
                                    gen1Start = true;
                                } else if(!gen2Start) {
                                    gen2Start = true;
                                } else if(!gen3Start) {
                                    gen3Start = true;
                                } if(!gen4Start) {
                                    gen4Start = true;
                                }
                            }
                        });

                    });
                } else {
                    if (room.getExits() == 4) {
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_4.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/4_entrances.jpg"));
                        }
                    } else if (room.getExits() == 3) {
                        forward.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_3.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/3_entrances.png"));
                        }
                    } else if (room.getExits() == 2) {
                        left.setEnabled(false);
                        right.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_2.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/2_entrances.jpg"));
                        }
                    } else {
                        forward.setEnabled(false);
                        right.setEnabled(false);
                        left.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_1.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/1_entrance.png"));
                        }
                    }
                }
                if (room.getName().equalsIgnoreCase("Elevator #4")) {
                    if (gen1Start && gen2Start && gen3Start && gen4Start) {
                        JOptionPane.showMessageDialog(this, "You have won the game!", "Congratulations!", JOptionPane.PLAIN_MESSAGE);
                        root.setVisible(true);
                        game.setVisible(false);
                    }
                }

            });

            right.addActionListener(f -> {
                slider.setValue(0);
                startGen.setVisible(false);
                forward.setEnabled(true);
                left.setEnabled(true);
                right.setEnabled(true);

                numBack = 0;

                Room room = newGame.createRoom();
                room.setIsGen();
                rooms.add(room);

                if(room.getIsGen()) {
                    if (!newGame.roomWorks(room)) {
                        startGen.setEnabled(false);
                    }
                    startGen.setVisible(true);
                    left.setEnabled(false);
                    right.setEnabled(false);
                    background.setIcon(new ImageIcon("resources/generator_room.jpg"));
                    startGen.addActionListener(h -> {
                        JButton run = new JButton("run");
                        run.setVisible(true);
                        startGen.setVisible(false);

                        west.add(run, BorderLayout.NORTH);

                        background.setIcon(new ImageIcon("resources/generator.jpg"));
                        slider.setVisible(true);

                        right.setEnabled(false);
                        left.setEnabled(false);
                        forward.setEnabled(false);
                        back.setEnabled(false);

                        run.addActionListener(g -> {
                            if (slider.getValue() == 5) {
                                background.setIcon(new ImageIcon("resources/generator_room.jpg"));
                                right.setEnabled(false);
                                left.setEnabled(false);
                                forward.setEnabled(true);
                                back.setEnabled(true);
                                slider.setVisible(false);
                                run.setVisible(false);

                                if(!gen1Start) {
                                    gen1Start = true;
                                } else if(!gen2Start) {
                                    gen2Start = true;
                                } else if(!gen3Start) {
                                    gen3Start = true;
                                } else {
                                    gen4Start = true;
                                }
                            }
                        });
                    });
                } else {
                    if (room.getExits() == 4) {
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_4.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/4_entrances.jpg"));
                        }
                    } else if (room.getExits() == 3) {
                        forward.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_3.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/3_entrances.png"));
                        }
                    } else if (room.getExits() == 2) {
                        left.setEnabled(false);
                        right.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_2.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/2_entrances.jpg"));
                        }
                    } else {
                        forward.setEnabled(false);
                        right.setEnabled(false);
                        left.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_1.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/1_entrance.png"));
                        }
                    }
                }
                if (room.getName().equalsIgnoreCase("Elevator #4")) {
                    if (gen1Start && gen2Start && gen3Start && gen4Start) {
                        JOptionPane.showMessageDialog(this, "You have won the game!", "Congratulations!", JOptionPane.PLAIN_MESSAGE);
                        root.setVisible(true);
                        game.setVisible(false);
                    }
                }

            });

            forward.addActionListener(f -> {
                slider.setValue(0);
                startGen.setVisible(false);
                forward.setEnabled(true);
                left.setEnabled(true);
                right.setEnabled(true);

                numBack = 0;

                Room room = newGame.createRoom();
                room.setIsGen();
                rooms.add(room);

                if(room.getIsGen()) {
                    if (!newGame.roomWorks(room)) {
                        startGen.setEnabled(false);
                    }
                    startGen.setVisible(true);
                    left.setEnabled(false);
                    right.setEnabled(false);
                    background.setIcon(new ImageIcon("resources/generator_room.jpg"));
                    startGen.addActionListener(h -> {
                        JButton run = new JButton("run");
                        run.setVisible(true);
                        startGen.setVisible(false);

                        west.add(run, BorderLayout.NORTH);

                        background.setIcon(new ImageIcon("resources/generator.jpg"));
                        slider.setVisible(true);

                        right.setEnabled(false);
                        left.setEnabled(false);
                        forward.setEnabled(false);
                        back.setEnabled(false);

                        run.addActionListener(g -> {
                            if (slider.getValue() == 5) {
                                background.setIcon(new ImageIcon("resources/generator_room.jpg"));
                                right.setEnabled(false);
                                left.setEnabled(false);
                                forward.setEnabled(true);
                                back.setEnabled(true);
                                slider.setVisible(false);
                                run.setVisible(false);
                                if(!gen1Start) {
                                    gen1Start = true;
                                } else if(!gen2Start) {
                                    gen2Start = true;
                                } else if(!gen3Start) {
                                    gen3Start = true;
                                } else {
                                    gen4Start = true;
                                }
                            }
                        });
                    });
                } else {
                    if (room.getExits() == 4) {
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_4.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/4_entrances.jpg"));
                        }
                    } else if (room.getExits() == 3) {
                        forward.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_3.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/3_entrances.png"));
                        }
                    } else if (room.getExits() == 2) {
                        left.setEnabled(false);
                        right.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_2.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/2_entrances.jpg"));
                        }
                    } else {
                        forward.setEnabled(false);
                        right.setEnabled(false);
                        left.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_1.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/1_entrance.png"));
                        }
                    }
                }
                if (room.getName().equalsIgnoreCase("Elevator #4")) {
                    if (gen1Start && gen2Start && gen3Start && gen4Start) {
                        JOptionPane.showMessageDialog(this, "You have won the game!", "Congratulations!", JOptionPane.PLAIN_MESSAGE);
                        root.setVisible(true);
                        game.setVisible(false);
                    }
                }

            });

            numBack = 0;
            back.addActionListener(f -> {
                slider.setValue(0);
                startGen.setVisible(false);
                forward.setEnabled(true);
                left.setEnabled(true);
                right.setEnabled(true);

                rooms.deleteLast();
                Room room = rooms.getItemAt(rooms.size() - 1);
                numBack += 1;

                if(room.getIsGen()) {
                    if (!newGame.roomWorks(room)) {
                        startGen.setEnabled(false);
                    }
                    startGen.setVisible(true);
                    left.setEnabled(false);
                    right.setEnabled(false);
                    background.setIcon(new ImageIcon("resources/generator_room.jpg"));
                    startGen.addActionListener(h -> {
                        JButton run = new JButton("run");
                        run.setVisible(true);
                        startGen.setVisible(false);

                        west.add(run, BorderLayout.NORTH);

                        background.setIcon(new ImageIcon("resources/generator.jpg"));
                        slider.setVisible(true);

                        right.setEnabled(false);
                        left.setEnabled(false);
                        forward.setEnabled(false);
                        back.setEnabled(false);

                        run.addActionListener(g -> {
                            if (slider.getValue() == 5) {
                                background.setIcon(new ImageIcon("resources/generator_room.jpg"));
                                right.setEnabled(false);
                                left.setEnabled(false);
                                forward.setEnabled(true);
                                back.setEnabled(true);
                                slider.setVisible(false);
                                run.setVisible(false);
                                if(!gen1Start) {
                                    gen1Start = true;
                                } else if(!gen2Start) {
                                    gen2Start = true;
                                } else if(!gen3Start) {
                                    gen3Start = true;
                                } else {
                                    gen4Start = true;
                                }
                            }
                        });
                    });
                } else {
                    if (room.getExits() == 4) {
                        entrances_4(room);
                    } else if (room.getExits() == 3) {
                        forward.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_3.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/3_entrances.png"));
                        }
                    } else if (room.getExits() == 2) {
                        left.setEnabled(false);
                        right.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_2.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/2_entrances.jpg"));
                        }
                    } else {
                        forward.setEnabled(false);
                        right.setEnabled(false);
                        left.setEnabled(false);
                        if(room.getIsEnemyHere()) {
                            background.setIcon(new ImageIcon("resources/SCP_1.png"));
                        } else {
                            background.setIcon(new ImageIcon("resources/1_entrance.png"));
                        }
                    }
                }
                if (room.getName().equalsIgnoreCase("Elevator #4")) {
                    if (gen1Start && gen2Start && gen3Start && gen4Start) {
                        JOptionPane.showMessageDialog(this, "You have won the game!", "Congratulations!", JOptionPane.PLAIN_MESSAGE);
                        root.setVisible(true);
                        game.setVisible(false);
                    }
                }

            });
            System.out.println("hello");
            fill();
            /*while(!startRoom.getName().equalsIgnoreCase("Elevator #4") || !gen4Start) {

                if (blink.getValue() == 100) {
                    blink.setValue(0);
                    background.setIcon(new ImageIcon("resources/blink.jpg"));
                }
            }*/
            System.out.println("Hello pt 2");
        });

        JButton help = new JButton("Help");
        help.setBackground(Color.black);
        help.setForeground(Color.white);

        help.addActionListener(e -> {
            JPanel helpPage = new JPanel();
            helpPage.setLayout(new BoxLayout(helpPage, BoxLayout.Y_AXIS));
            helpPage.setBorder(new EmptyBorder(10, 10, 10, 10));
            JTextArea helpInfo = new JTextArea();
            helpInfo.setText("this didn't work please work");
            JButton back = new JButton("Back");
            //helpInfo.setAlignmentX(CENTER_ALIGNMENT);
            helpInfo.setBounds(100, 100, 100, 100);

            helpPage.setBackground(Color.black);
            helpInfo.setBackground(Color.black);
            helpInfo.setForeground(Color.white);
            back.setBackground(Color.black);
            back.setForeground(Color.white);

            helpPage.add(helpInfo, BorderLayout.CENTER);
            helpPage.add(back);

            this.getContentPane().add(helpPage);

            root.setVisible(false);
            helpPage.setVisible(true);

            back.addActionListener(f -> {
                helpPage.setVisible(false);
                root.setVisible(true);

                this.setExtendedState(JFrame.MAXIMIZED_BOTH);
            });
        });

        JButton load = new JButton("Load");
        load.setBackground(Color.black);
        load.setForeground(Color.white);

        load.addActionListener(e -> {
            JPanel loadPage = new JPanel();
            loadPage.setLayout(new BoxLayout(loadPage, BoxLayout.Y_AXIS));
            loadPage.setBackground(Color.black);

            JPanel loadButtons = new JPanel();
            loadButtons.setLayout(new GridLayout(3, 1));
            loadButtons.setBorder(new EmptyBorder(50, 50, 50, 50));
            loadButtons.setBackground(Color.black);

            JButton load1 = new JButton("Load 1");
            load1.setBackground(Color.darkGray);
            load1.setForeground(Color.white);
            JButton load2 = new JButton("Load 2");
            load2.setBackground(Color.darkGray);
            load2.setForeground(Color.white);
            JButton load3 = new JButton("Load 3");
            load3.setBackground(Color.darkGray);
            load3.setForeground(Color.white);

            JButton back = new JButton("Back");
            back.setAlignmentX(CENTER_ALIGNMENT);
            back.setBackground(Color.black);
            back.setForeground(Color.white);

            loadButtons.add(load1);
            loadButtons.add(load2);
            loadButtons.add(load3);

            loadPage.add(loadButtons);
            loadPage.add(back);
            this.getContentPane().add(loadPage);

            root.setVisible(false);
            loadPage.setVisible(true);

            load1.addActionListener(f -> {
                JOptionPane.showMessageDialog(this, "The dev hasn't coded this yet!", "ERROR", JOptionPane.PLAIN_MESSAGE);
            });

            load2.addActionListener(f -> {
                JOptionPane.showMessageDialog(this, "The dev hasn't coded this yet!", "ERROR", JOptionPane.PLAIN_MESSAGE);
            });

            load3.addActionListener(f -> {
                JOptionPane.showMessageDialog(this, "The dev hasn't coded this yet!", "ERROR", JOptionPane.PLAIN_MESSAGE);
            });

            back.addActionListener(f -> {
                loadPage.setVisible(false);
                root.setVisible(true);

                this.setExtendedState(JFrame.MAXIMIZED_BOTH);
            });
        });

        JButton quit = new JButton("Quit");
        quit.setBackground(Color.black);
        quit.setForeground(Color.white);

        quit.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Thank you for playing!", "Goodbye", JOptionPane.PLAIN_MESSAGE);
            System.exit(0);
        });

        startMenu.add(gameName);

        startButtons.add(start);
        startButtons.add(load);
        startButtons.add(help);
        startButtons.add(quit);

        root.add(startMenu);

        root.add(startButtons);

        this.getContentPane().add(root);

        // this sets up the GUI
        this.setTitle("SCP - Containment Breach");
        this.setSize(500, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);

        /*timer = new Timer(1000, event -> {
            // timer stuff
            time -= 10;
            timeLabel.setText("Time: " + time);

            if (time == 0) {
                timer.setRepeats(true);
                background.setIcon(new ImageIcon("resources/blink.jpg"));
            }
        });*/

    }

    // https://www.geeksforgeeks.org/java-swing-jprogressbar/#:~:text=JProgressBar%20is%20a%20part%20of%20Java%20Swing%20package.,of%20task,%20it%20can%20also%20display%20some%20text.
    public void fill()
    {
        System.out.println("hey bud");
        int i = 0;
        try {
            System.out.println("youre stupid!");
            while (i <= 100) {
                // fill the menu bar
                blink.setValue(i + 10);
                System.out.println("this worked!");
                // delay the thread
                Thread.sleep(1000);
                i += 10;

                if (blink.getValue() == 100) {
                    blink.setValue(0);
                    background.setIcon(new ImageIcon("resources/blink.jpg"));
                }
            }
        }
        catch (Exception e) {
            System.out.println("something went wrong!");
        }
    }

    /*public void entrances_4(Room room) {
        if(room.getIsEnemyHere()) {
            background.setIcon(new ImageIcon("resources/SCP_4.png"));
        } else {
            background.setIcon(new ImageIcon("resources/4_entrances.jpg"));
        }
    }*/

    // this runs the GUI
    public static void main(String[] args) {

        // this creates a new Main method for the GUI to run in
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Main();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }


}