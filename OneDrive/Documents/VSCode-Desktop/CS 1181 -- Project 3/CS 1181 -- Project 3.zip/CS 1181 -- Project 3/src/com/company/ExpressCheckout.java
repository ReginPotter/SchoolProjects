package com.company;

public class ExpressCheckout extends CheckoutLane{

}
