package com.company;

public class RegularCheckout extends CheckoutLane{

}
