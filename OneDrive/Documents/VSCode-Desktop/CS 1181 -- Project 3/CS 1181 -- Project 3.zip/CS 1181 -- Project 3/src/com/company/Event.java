package com.company;

public class Event implements Comparable<Event> {

    private Customer customer;
    private double time;

    public Event(Customer customer) {
        this.customer = customer;
        time = customer.getArrivalTime();
    }

    public int compareTo(Event other) {
        if (this.time > other.time) {
            return 1;
        } else if (this.time < other.time) {
            return -1;
        } else {
            return 0;
        }
    }

    public String toString() {
        return "arrived: " + time + " items: " + customer.getItems() + " time per item: " + customer.getTimeSpent();
    }
}
