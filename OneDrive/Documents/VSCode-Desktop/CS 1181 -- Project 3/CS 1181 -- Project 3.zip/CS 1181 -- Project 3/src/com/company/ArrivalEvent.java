package com.company;

public class ArrivalEvent extends Event {

    public ArrivalEvent(Customer customer) {
        super(customer);
    }
}
