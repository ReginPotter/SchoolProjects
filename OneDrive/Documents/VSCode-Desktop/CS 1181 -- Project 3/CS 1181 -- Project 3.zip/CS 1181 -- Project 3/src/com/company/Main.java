package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        double eventClock = 0.0;

        ArrayList<Customer> customers = readData();

        PriorityQueue<Event> events = createEvents(customers);
        Event currentEvent = events.poll();
        System.out.println(currentEvent);
        currentEvent = events.poll();
        System.out.println(currentEvent);
        currentEvent = events.poll();
        System.out.println(currentEvent);
        currentEvent = events.poll();
        System.out.println(currentEvent);
    }

    public static ArrayList<Customer> readData() throws FileNotFoundException {
        Scanner in = new Scanner(new File("arrival.txt"));
        ArrayList<Customer> customers = new ArrayList<>();

        while(in.hasNext()) {
            String line = in.nextLine();
            Scanner splitString = new Scanner(line);
            splitString.useDelimiter("   ");

            Customer customer = new Customer(splitString.nextDouble(), splitString.nextInt(), splitString.nextDouble());
            customers.add(customer);
        }
        return customers;
    }

    public static PriorityQueue<Event> createEvents(ArrayList<Customer> customers) {
        PriorityQueue<Event> events = new PriorityQueue<>();

        for(Customer c: customers) {
            ArrivalEvent arrive = c.makeArrivalEvent();

            events.add(arrive);
        }
        return events;
    }
}
