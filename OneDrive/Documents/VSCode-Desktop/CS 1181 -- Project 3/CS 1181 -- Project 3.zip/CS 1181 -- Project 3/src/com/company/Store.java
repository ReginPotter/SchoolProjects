package com.company;

public class Store {

}
