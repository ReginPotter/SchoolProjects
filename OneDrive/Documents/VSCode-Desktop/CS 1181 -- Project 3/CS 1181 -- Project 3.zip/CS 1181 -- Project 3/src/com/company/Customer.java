package com.company;

public class Customer implements Comparable<Customer> {

    double arrivalTime;
    int items;
    double timeSpent;
    boolean checkingOut = false;

    public Customer(double arrivalTime, int items, double timeSpent) {
        this.arrivalTime = arrivalTime;
        this.items = items;
        this.timeSpent = timeSpent;
    }

    public double shoppingTime() {
        double shoppingTime = arrivalTime + (items * timeSpent);
        return shoppingTime;
    }

    public ArrivalEvent makeArrivalEvent() {
        ArrivalEvent ae = new ArrivalEvent(this);

        return ae;
    }

    public double getArrivalTime() {
        return arrivalTime;
    }

    public int getItems() {
        return items;
    }

    public double getTimeSpent() {
        return  timeSpent;
    }

    public boolean checkingOut(double time) {
        if(shoppingTime() == time) {
            checkingOut = true;
            return true;
        }
        return false;
    }

    public int compareTo(Customer other) {
        if (this.arrivalTime > other.arrivalTime) {
            return 1;
        } else if (this.arrivalTime < other.arrivalTime) {
            return -1;
        } else {
            return 0;
        }
    }

    public String toString() {
        return "arrived: " + arrivalTime + " items: " + items + " time per item: " + timeSpent;
    }
}
