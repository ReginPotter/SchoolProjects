package com.company;

public class FinishedShoppingEvent extends Event {

    public FinishedShoppingEvent(Customer customer) {
        super(customer);
    }
}
