package com.company;

import java.util.Queue;

public class CheckoutLane implements Comparable<CheckoutLane>{
    private Queue<Customer> line;

    public int compareTo(CheckoutLane other) {
        return 0;
    }
}
