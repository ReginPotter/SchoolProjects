package com.company;

public class FinishedCheckoutEvent extends Event {

    public FinishedCheckoutEvent(Customer customer) {
        super(customer);
    }
}
