package com.company;

import javax.imageio.ImageIO;
import javax.print.Doc;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.Document;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.concurrent.Flow;

class Main extends JFrame {

    public Main() throws IOException {

        // this creates the root JPanel
        JPanel root = new JPanel() {

            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image image = null;
                try {
                    image = ImageIO.read(new File("resources/scp.jpg"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                g.drawImage(image, -240, -260, null);
            }
        };
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel startMenu = new JPanel();
        startMenu.setLayout(new GridLayout());
        startMenu.setOpaque(false);

        JLabel gameName = new JLabel();
        gameName.setForeground(Color.white);
        gameName.setOpaque(false);
        gameName.setFont(new Font("Arial", Font.PLAIN, 30));
        gameName.setText("SCP - Containment Breach");
        gameName.setHorizontalAlignment(JLabel.CENTER);

        JPanel startButtons = new JPanel();
        startButtons.setBackground(Color.black);
        startButtons.setOpaque(false);
        startButtons.setBorder(new EmptyBorder(10, 10 ,10, 10));
        startButtons.setLayout(new FlowLayout());

        JButton start = new JButton("Start");
        start.setBackground(Color.black);
        start.setForeground(Color.white);

        start.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "The dev hasn't coded this yet! Sorry!", "ERROR", JOptionPane.PLAIN_MESSAGE);
        });

        JButton help = new JButton("Help");
        help.setBackground(Color.black);
        help.setForeground(Color.white);

        help.addActionListener(e -> {
            JPanel helpPage = new JPanel();
            helpPage.setLayout(new BoxLayout(helpPage, BoxLayout.Y_AXIS));
            helpPage.setBorder(new EmptyBorder(10, 10, 10, 10 ));
            JTextArea helpInfo = new JTextArea();
            helpInfo.setText("this didnt work please work");
            JButton back = new JButton("Back");
            helpInfo.setAlignmentX(CENTER_ALIGNMENT);
            helpInfo.setBounds(100, 100, 100, 100);

            helpPage.setBackground(Color.black);
            helpInfo.setBackground(Color.black);
            helpInfo.setForeground(Color.white);
            back.setBackground(Color.black);
            back.setForeground(Color.white);

            helpPage.add(helpInfo, BorderLayout.CENTER);
            helpPage.add(back);

            this.getContentPane().add(helpPage);

            root.setVisible(false);
            helpPage.setVisible(true);

            back.addActionListener(f -> {
                helpPage.setVisible(false);
                root.setVisible(true);

                this.setExtendedState(JFrame.MAXIMIZED_BOTH);
            });
        });

        JButton load = new JButton("Load");
        load.setBackground(Color.black);
        load.setForeground(Color.white);

        load.addActionListener(e -> {
            JPanel loadPage = new JPanel();
            loadPage.setLayout(new BoxLayout(loadPage, BoxLayout.Y_AXIS));
            loadPage.setBackground(Color.black);

            JPanel loadButtons = new JPanel();
            loadButtons.setLayout(new GridLayout(3, 1));
            loadButtons.setBorder(new EmptyBorder(50, 50, 50, 50));
            loadButtons.setBackground(Color.black);

            JButton load1 = new JButton("Load 1");
            load1.setBackground(Color.darkGray);
            load1.setForeground(Color.white);
            JButton load2 = new JButton("Load 2");
            load2.setBackground(Color.darkGray);
            load2.setForeground(Color.white);
            JButton load3 = new JButton("Load 3");
            load3.setBackground(Color.darkGray);
            load3.setForeground(Color.white);

            JButton back = new JButton("Back");
            back.setAlignmentX(CENTER_ALIGNMENT);
            back.setBackground(Color.black);
            back.setForeground(Color.white);

            loadButtons.add(load1);
            loadButtons.add(load2);
            loadButtons.add(load3);

            loadPage.add(loadButtons);
            loadPage.add(back);
            this.getContentPane().add(loadPage);

            root.setVisible(false);
            loadPage.setVisible(true);

            load1.addActionListener(f -> {
                JOptionPane.showMessageDialog(this, "The dev hasn't coded this yet!", "ERROR", JOptionPane.PLAIN_MESSAGE);
            });

            load2.addActionListener(f -> {
                JOptionPane.showMessageDialog(this, "The dev hasn't coded this yet!", "ERROR", JOptionPane.PLAIN_MESSAGE);
            });

            load3.addActionListener(f -> {
                JOptionPane.showMessageDialog(this, "The dev hasn't coded this yet!", "ERROR", JOptionPane.PLAIN_MESSAGE);
            });

            back.addActionListener(f -> {
                loadPage.setVisible(false);
                root.setVisible(true);

                this.setExtendedState(JFrame.MAXIMIZED_BOTH);
            });
        });

        JButton quit = new JButton("Quit");
        quit.setBackground(Color.black);
        quit.setForeground(Color.white);

        quit.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Thank you for playing!", "Goodbye", JOptionPane.PLAIN_MESSAGE);
            System.exit(0);
        });

        startMenu.add(gameName);

        startButtons.add(start);
        startButtons.add(load);
        startButtons.add(help);
        startButtons.add(quit);

        root.add(startMenu);

        root.add(startButtons);

        this.getContentPane().add(root);

        // this sets up the GUI
        this.setTitle("SCP - Containment Breach");
        this.setSize(500, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);

    }

    // this runs the GUI
    public static void main(String[] args) {

        // this creates a new Main method for the GUI to run in
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Main();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}